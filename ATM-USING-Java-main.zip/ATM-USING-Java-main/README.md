# ATM-USING-Java
In the ATM program, the user has to select an option from the options displayed on the screen. The options are related to withdraw the money, deposit the money, check the balance, and exit.

To withdraw the money, we simply get the withdrawal amount from the user and remove that amount from the total balance and print the successful message.

To deposit the money, we simply get the deposit amount from the user, add it to the total balance and print the successful message.

To check balance, we simply print the total balance of the user.

We use the exit(0) method to exit from the current Transaction mode and return the user to the home page or initial screen.
